<?php

function max_script_enqueue(){

	

	// Bootstrap
	wp_enqueue_style('bootstrap-min', get_template_directory_uri() . '/css/bootstrap/css/bootstrap.min.css', array(), '1.0.0', 'all');

	// Font Awesome
	wp_enqueue_style('font-awesome', get_template_directory_uri() . '/css/font-awesome/css/font-awesome.min.css', array(), '1.0.0', 'all');
	// NProgress
	wp_enqueue_style('nprogress-css', get_template_directory_uri() . '/nprogress/nprogress.css', array(), '1.0.0', 'all');
	// Green
	wp_enqueue_style('green-css', get_template_directory_uri() . '/css/green.css', array(), '1.0.0', 'all');
	// Progressbar
	wp_enqueue_style('bootstrap-progressbar', get_template_directory_uri() . '/css/bootstrap-progressbar-3.3.4.min.css', array(), '1.0.0', 'all');
	// JQVMap
	wp_enqueue_style('jqvmap-css', get_template_directory_uri() . '/jqvmap/jqvmap.min.css', array(), '1.0.0', 'all');
	// daterangepicker
	wp_enqueue_style('daterangepicker-css', get_template_directory_uri() . '/bootstrap-daterangepicker/daterangepicker.css', array(), '1.0.0', 'all');
	// Custom Theme Style
	wp_enqueue_style('custom-css', get_template_directory_uri() . '/css/custom.min.css', array(), '1.0.0', 'all');







	// JS

	// Fastclick
	wp_enqueue_script('fastclick-js', get_template_directory_uri() . '/js/fastclick.js', array(), '1.0.0', true);
	// NProgress
	wp_enqueue_script('nprogress-js', get_template_directory_uri() . '/nprogress/nprogress.js', array(), '1.0.0', true);
	// Chart
	wp_enqueue_script('nprogress-min', get_template_directory_uri() . '/js/chart/Chart.min.js', array(), '1.0.0', true);
	// Gauge
	wp_enqueue_script('gauge-min', get_template_directory_uri() . '/js/dist/gauge.min.js', array(), '1.0.0', true);
	// Bootstrap Progressbar
	wp_enqueue_script('progressbar-min', get_template_directory_uri() . '/js/bootstrap-progressbar.min.js', array(), '1.0.0', true);
	// ICheck
	wp_enqueue_script('icheck-min', get_template_directory_uri() . '/js/iCheck/icheck.min.js', array(), '1.0.0', true);
	// Skycons
	wp_enqueue_script('skycons-js', get_template_directory_uri() . '/js/skycons/skycons.js', array(), '1.0.0', true);
	// Flot
	wp_enqueue_script('flot-js', get_template_directory_uri() . '/js/Flot/jquery.flot.js', array(), '1.0.0', true);
	wp_enqueue_script('pie-js', get_template_directory_uri() . '/js/Flot/jquery.flot.pie.js', array(), '1.0.0', true);
	wp_enqueue_script('time-js', get_template_directory_uri() . '/js/Flot/jquery.flot.time.js', array(), '1.0.0', true);
	wp_enqueue_script('stack-js', get_template_directory_uri() . '/js/Flot/jquery.flot.stack.js', array(), '1.0.0', true);
	wp_enqueue_script('resize-js', get_template_directory_uri() . '/js/Flot/jquery.flot.resize.js', array(), '1.0.0', true);
	// // Flot Plugins
	wp_enqueue_script('orderBars-js', get_template_directory_uri() . '/js/jquery.flot.orderBars.js', array(), '1.0.0', true);
	wp_enqueue_script('spline-min', get_template_directory_uri() . '/js/jquery.flot.spline.min.js', array(), '1.0.0', true);
	wp_enqueue_script('curvedlines-js', get_template_directory_uri() . '/js/flot.curvedlines/curvedLines.js', array(), '1.0.0', true);
	// // Date
	wp_enqueue_script('date-js', get_template_directory_uri() . '/js/date/date.js', array(), '1.0.0', true);
	// // JQVMap
	wp_enqueue_script('vmap-js', get_template_directory_uri() . '/js/jqvmap/dist/jquery.vmap.js', array(), '1.0.0', true);
	wp_enqueue_script('world-js', get_template_directory_uri() . '/js/jqvmap/dist/maps/jquery.vmap.world.js', array(), '1.0.0', true);
	wp_enqueue_script('sampledata-js', get_template_directory_uri() . '/js/jqvmap/examples/js/jquery.vmap.sampledata.js', array(), '1.0.0', true);
	// bootstrap-daterangepicker
	wp_enqueue_script('moment-min', get_template_directory_uri() . '/js/min/moment.min.js', array(), '1.0.0', true);
	wp_enqueue_script('daterangepicker-js', get_template_directory_uri() . '/bootstrap-daterangepicker/daterangepicker.js', array(), '1.0.0', true);



	// Custom
	wp_enqueue_script('custom-min', get_template_directory_uri() . '/js/custom.min.js', array(), '1.0.0', true);



	
}

add_action('wp_enqueue_scripts', 'max_script_enqueue');

?>