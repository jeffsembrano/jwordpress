<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" href="<?php echo get_template_directory_uri()?> /images/favicon.ico" type="image/ico" />

    <?php wp_head(); ?>

    <title>Gentelella Alela! | </title>

     <!-- Bootstrap -->
    <link href="/wordpress/wordpress/wp-content/themes/gentelellasample/css/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="/wordpress/wordpress/wp-content/themes/gentelellasample/css/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="/wordpress/wordpress/wp-content/themes/gentelellasample/nprogress/nprogress.css" rel="stylesheet">
     <!-- iCheck -->
    <link href="/wordpress/wordpress/wp-content/themes/gentelellasample/css/green.css" rel="stylesheet">
  
    <!-- bootstrap-progressbar -->
    <link href="/wordpress/wordpress/wp-content/themes/gentelellasample/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
    <!-- JQVMap -->
    <link href="/wordpress/wordpress/wp-content/themes/gentelellasample/jqvmap/jqvmap.min.css" rel="stylesheet"/>
    <!-- bootstrap-daterangepicker -->
    <link href="/wordpress/wordpress/wp-content\themes/gentelellasample/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="/wordpress/wordpress/wp-content/themes/gentelellasample/css/custom.min.css" rel="stylesheet">


      <!-- jQuery -->
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/jquery/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/bootstrap/js/bootstrap.min.js"></script>
   <!-- FastClick -->
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/fastclick.js"></script>
    <!-- NProgress -->
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/nprogress/nprogress.js"></script>
    <!-- Chart.js -->
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/chart/Chart.min.js"></script>
    <!-- gauge.js -->
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/gauge/gauge.min.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/iCheck/icheck.min.js"></script>
    <!-- Skycons -->
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/skycons/skycons.js"></script>
    <!-- Flot -->
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/skycons/jquery.flot.js"></script>
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/skycons/jquery.flot.pie.js"></script>
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/skycons/jquery.flot.time.js"></script>
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/skycons/jquery.flot.stack.js"></script>
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/skycons/jquery.flot.resize.js"></script>
    <!-- Flot plugins -->
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/jquery.flot.orderBars.js"></script>
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/jquery.flot.spline.min.js"></script>
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/flot.curvedlines/curvedLines.js"></script>
    <!-- DateJS -->
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/date/date.js"></script>
    <!-- JQVMap -->
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/jqvmap/jquery.vmap.js"></script>
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/jqvmap/maps/jquery.vmap.world.js"></script>
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/min/moment.min.js"></script>
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/bootstrap-daterangepicker/daterangepicker.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/custom.min.js"></script>


  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">